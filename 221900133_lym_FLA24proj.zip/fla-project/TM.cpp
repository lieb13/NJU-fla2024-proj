#include "TM.h"

void TM::initialize_(std::string input) {
    current_state_ = start_state_;
    if (verbose_) {
        std::cout << "Input: " << input << std::endl;
    }
    for (char symbol : input){
        // try {
            checkInputSymbol(symbol);
        // } catch (IllegalInput& e) {
        //     if (verbose_) {
        //         std::cerr << ERR << "error: '" << symbol << "' was not declared in the set of input symbols\n"  \
        //             << "Input: " << input << std::endl;
        //     }
        // }
    }
    tapes_.resize(tape_count_);
    tape_heads_.resize(tape_count_);
    for (int i = 1; i < tape_count_; i++){
        tapes_[i].push_back(BLANK);
        tape_heads_[i] = 0;
    }
    for (char symbol : input){
        tapes_[0].push_back(symbol);
    }
    tape_heads_[0] = 0;

    // for (auto trans : transitions_){
    //     std::cout << std::get<0>(trans.first) << "  " << std::get<1>(trans.first) << std::endl;
    // }
    // std::cout << "Size=" << transitions_.size() << std::endl;
    if (verbose_) {
        std::cout << RUN;
        std::cout << "Step   : " << 0 << std::endl;
        std::cout << "State  : " << current_state_ << std::endl;
        for (int i = 0; i < tape_count_; i++){
            std::cout << "Tape " << i << ": ";
            for (int j = 0; j < tapes_[i].size(); j++){
                if (j == tape_heads_[i]){
                    std::cout << "[" << tapes_[i][j] << "]";
                }
                else{
                    std::cout << " " << tapes_[i][j] << " ";
                }
            }
            std::cout << std::endl;
        }
        std::cout << LINE;
    }
}

bool TM::simulater(const std::string& input) {
    initialize_(input);
    int step = 0;
    while (transition_()){
        // return false;
        // verbose_ = true;
        step++;
        if (verbose_){
            std::cout << "Step   : " << step << std::endl;
            std::cout << "State  : " << current_state_ << std::endl;
            for (int i = 0; i < tape_count_; i++){
                std::cout << "Tape " << i << ": ";
                for (int j = 0; j < tapes_[i].size(); j++){
                    if (j == tape_heads_[i]){
                        std::cout << "[" << tapes_[i][j] << "]";
                    }
                    else{
                        std::cout << " " << tapes_[i][j] << " ";
                    }
                }
                std::cout << std::endl;
            }
            std::cout << LINE;
        }

    }
    return final_states_.find(current_state_) != final_states_.end();
}

std::string TM::printResult(){
    std::string result = "";
    int it = 0;
    while (tapes_[0][it] == BLANK){
        it++;
    }
    while (it < tapes_[0].size()){
        result += (tapes_[0][it] == BLANK ? ' ' : tapes_[0][it]);
        it++;
    }
    while (result.back() == ' '){
        result.pop_back();
    }
    return result;
}

std::vector<InOutPair> TM::expandSymbolGroup_(const InOutPair& inOutPair) {
    std::vector<InOutPair> result = {};
    result.push_back(std::make_pair("","")); // 初始为空

    // std::cerr << inOutPair.first << " " << inOutPair.second << std::endl;
    for (int i = 0; i < inOutPair.first.size(); i++) {
        char in = inOutPair.first[i];
        char out = inOutPair.second[i];
        std::vector<InOutPair> newResult = {};
        for (const auto& prefix : result) {
            if (in == ANY && out == ANY) {
                for (char symbol : tape_symbols_) {
                    if (symbol != BLANK) {
                        newResult.push_back(std::make_pair(prefix.first + symbol,\
                            prefix.second + symbol));
                    }
                }
            }
            else if (in == ANY && out != ANY) {
                for (char symbol : tape_symbols_) {
                    if (symbol != BLANK) {
                        newResult.push_back(std::make_pair(prefix.first + symbol,\
                        prefix.second + out));
                    }
                }
            }
            else if (in != ANY && out == ANY) {
                throw SyntaxError("Invalid transition format");
            }
            else {
                newResult.push_back(std::make_pair(prefix.first + in,\
                    prefix.second + out));
            }
        }
        result = newResult;
    }

    return result;
}

void TM::addTransition(const State& from, const std::string& input, \
        const std::string& output, const std::string& direction, const State& to){
    if (input.length() != tape_count_ || direction.length() != tape_count_ || \
        output.length() != tape_count_){
        throw SyntaxError("Invalid transition format");
    }
    for (int i = 0; i < tape_count_; i++){
        checkTapeSymbol(input[i]);
        checkTapeSymbol(output[i]);
        checkDirection(direction[i]);
    }

    auto inOutPairs = expandSymbolGroup_(std::make_pair(input, output));
    for (const auto& inOutPair : inOutPairs) {
        transitions_[{from, inOutPair.first}] = {to, inOutPair.second, direction};
    }
}    

bool TM::transition_(){ 
    std::string input = "";
    for (int i = 0; i < tape_count_; i++){
        if (tape_heads_[i] < tapes_[i].size()){
            input += tapes_[i][tape_heads_[i]];
        }
        else{
            input += BLANK;
        }
    }

    auto key = std::make_tuple(current_state_, input);
    if (transitions_.find(key) != transitions_.end()){
        State new_state; std::string output; std::string direction;
        std::tie(new_state, output, direction) = transitions_[key];
        current_state_ = new_state;
        for (int i = 0; i < tape_count_; i++){
            tapes_[i][tape_heads_[i]] = output[i];
            if (direction[i] == LEFT){
                if (tape_heads_[i] == 0) {
                    tapes_[i].push_front(BLANK);
                }
                else {
                    tape_heads_[i] -= 1;
                }
                // while (tapes_[i].back() == BLANK && tapes_[i].size() > 1){
                //     tapes_[i].pop_back();
                // }
            }
            else if (direction[i] == RIGHT){
                if (tape_heads_[i] == tapes_[i].size() - 1){
                    tapes_[i].push_back(BLANK);
                }
                tape_heads_[i] += 1;
                // while (tapes_[i].front() == BLANK && tapes_[i].size() > 1){
                //     tapes_[i].pop_front();
                //     tape_heads_[i] -= 1;
                // }
            }
        }
        return true;
    }
    return false;
}