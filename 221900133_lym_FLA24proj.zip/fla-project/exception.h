#pragma once

#include <iostream>
#include <stdexcept>
#include <string>

#define ERR "==================== ERR ====================\n"
#define RUN "==================== RUN ====================\n"
#define END "==================== END ====================\n"
#define LINE "---------------------------------------------\n"

// std::string positionPointer(int pos, const std::string& msg){

// }

class SyntaxError : public std::exception {
private:
    std::string message;

public:
    SyntaxError(const std::string& msg) : message("Syntax Error\n" +msg) {}

    const char* what() const noexcept override {
        return message.c_str();
    }
};

class IllegalInput : public std::exception {
private:
    std::string message;

public:
    IllegalInput(const std::string& msg) : message("Illegal Input\n" +msg) {}

    const char* what() const noexcept override {
        return message.c_str();
    }
};
